package rs.edu.raf.mtomic.paclike;

public enum FieldState {
    BLOCKED, EMPTY, PELLET
}
