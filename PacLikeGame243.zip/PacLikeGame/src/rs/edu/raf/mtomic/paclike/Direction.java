package rs.edu.raf.mtomic.paclike;

public enum Direction {
    UP, LEFT, DOWN, RIGHT
}
